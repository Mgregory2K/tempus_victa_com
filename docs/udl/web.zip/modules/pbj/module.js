
import { el } from "/ui/shared/ui.js";
import { Records } from "/ui/shared/records.js";

// Force local Records mode for stability (server mode optional later)
Records.use("local");

function safe(v){ return (v==null? "" : String(v)); }

function uid(prefix="PBJ"){
  try{ return `${prefix}-${crypto.randomUUID().slice(0,8)}`; }
  catch{ return `${prefix}-${Math.floor(100000+Math.random()*900000)}`; }
}

function toast(msg, kind="ok"){
  const root = document.getElementById("root") || document.body;
  let host = document.getElementById("toastHost");
  if(!host){
    host = el("div",{id:"toastHost", class:"toastHost"},[]);
    root.appendChild(host);
  }
  const t = el("div",{class:`toast ${kind}`},[msg]);
  host.appendChild(t);
  setTimeout(()=>t.classList.add("show"), 10);
  setTimeout(()=>{ t.classList.remove("show"); t.classList.add("hide"); }, 2200);
  setTimeout(()=>{ try{ t.remove(); }catch{} }, 2600);
}

function lsGet(k, d){
  try{ const v = localStorage.getItem(k); return v==null ? d : v; }catch{ return d; }
}
function lsSet(k, v){
  try{ localStorage.setItem(k, v); }catch{}
}


function navOpenRecordId(){
  try{ return localStorage.getItem("udl_nav_open_record") || ""; }catch{ return ""; }
}
function clearNavOpenRecordId(){
  try{ localStorage.removeItem("udl_nav_open_record"); }catch{}
}
function focusFromNav(){
  const id = navOpenRecordId();
  if(!id) return;
  const card = document.querySelector(`[data-record-id="${CSS.escape(id)}"]`);
  if(card){
    card.classList.add("focusPulse");
    card.scrollIntoView({behavior:"smooth", block:"center"});
    setTimeout(()=>card.classList.remove("focusPulse"), 1800);
    clearNavOpenRecordId();
  }
}

async function listPBJs(){
  const all = Records.byType("pbj");
  return (all||[]).sort((a,b)=> (b.updatedAt||"").localeCompare(a.updatedAt||""));
}

async function createShipFromPBJ(pbj){
  try{
    const now = new Date().toISOString();
    const shipId = uid("UDL");
    const sev = pbj.priority || pbj.fields?.severity || "P3";
    const title = pbj.title || "Ship item (from PBJ)";
    const desc = pbj.fields?.description || "";
    const owner = pbj.owner || "Michael";

    const ship = {
      id: shipId,
      type: "ship",
      title,
      status: "todo",
      priority: sev,
      owner,
      tags: Array.from(new Set(["from-pbj", ...(pbj.tags||[])])),
      workspaceId: pbj.workspaceId || "default",
      links: { parentId: pbj.id, relatedIds: [] },
      fields: { sev, description: desc },
      evidence: { notes: "" },
      audit: [{ at: now, msg: `Created from PBJ ${pbj.id}` }],
      createdAt: now,
      updatedAt: now,
    };

    pbj.links = pbj.links || { parentId: undefined, relatedIds: [] };
    const rel = Array.isArray(pbj.links.relatedIds) ? pbj.links.relatedIds : [];
    if(!rel.includes(shipId)) rel.push(shipId);
    pbj.links.relatedIds = rel;
    pbj.updatedAt = now;
    pbj.audit = Array.isArray(pbj.audit) ? pbj.audit : [];
    pbj.audit.push({ at: now, msg: `Created Ship item ${shipId}` });

    await Records.upsertAsync(ship);
    await Records.upsertAsync(pbj);

    try{ window.parent?.postMessage({type:"udl-nav", path:"/ship", openRecordId: shipId}, "*"); }catch{}
    toast("Ship item created", "ok");
  }catch(e){
    console.error(e);
    toast("Ship create failed", "err");
  }
}

function normalizePBJFromIntake(payload){
  const now = new Date().toISOString();
  const title =
    payload.title ||
    payload.business_name ||
    payload.businessName ||
    payload.project_name ||
    payload.business_name ||
    "New PBJ";

  const owner =
    payload.owner ||
    payload.client_name ||
    payload.clientName ||
    "Michael";

  const priority =
    payload.priority ||
    payload.severity ||
    payload.sev ||
    "P3";

  const tags = []
    .concat(payload.tags || [])
    .concat(payload.snapshot_goal || [])
    .map(x=> (x||"").toString().trim())
    .filter(Boolean);

  const desc =
    payload.description ||
    payload.win_definition ||
    payload.pain_issue ||
    payload.suspected_wrong ||
    payload.acquisition_payment ||
    "";

  const pbjId = uid("PBJ");
  return {
    id: pbjId,
    type: "pbj",
    title: title.toString().slice(0,140),
    status: "new",
    priority: priority.toString(),
    owner: owner.toString(),
    tags: Array.from(new Set(["pbj", ...tags])),
    workspaceId: "default",
    links: { parentId: undefined, relatedIds: [] },
    fields: {
      description: desc.toString(),
      intake: payload
    },
    evidence: { notes: "" },
    audit: [{ at: now, msg: "Created from intake submit" }],
    createdAt: now,
    updatedAt: now,
  };
}

let recentHost = null;

function pbjCard(r){
  const linked = r.links?.relatedIds?.length || 0;
  return el("div",{class:"card pbjCard", "data-record-id": r.id},[
    el("div",{class:"hd"},[
      el("div",{},[
        el("div",{class:"h3"},[safe(r.title)||"(untitled)"]),
        el("div",{class:"subtle"},[r.id])
      ]),
      el("div",{class:"row", style:"gap:10px;"},[
        el("button",{class:"btn", onClick:()=>{ try{ localStorage.setItem("udl_nav_open_record", r.id); }catch{}; focusFromNav(); }},["Focus"]),
        el("button",{class:"btn primary", onClick:async()=>{ await createShipFromPBJ(r); }},["Create Ship Item"])
      ])
    ]),
    el("div",{class:"bd"},[
      el("div",{class:"row", style:"gap:8px; flex-wrap:wrap;"},[
        el("span",{class:"chip"},[r.status||"new"]),
        el("span",{class:"chip"},[r.priority||"P3"]),
        el("span",{class:"chip"},[linked? `${linked} linked` : "no links"]),
      ]),
      el("div",{class:"mini", style:"margin-top:10px; white-space:pre-line;"},[
        (r.fields?.description || "No description yet.")
      ])
    ])
  ]);
}

async function refreshRecent(){
  if(!recentHost) return;
  recentHost.innerHTML = "";
  let recs = [];
  try{
    recs = await listPBJs();
  }catch(e){
    recentHost.appendChild(el("div",{class:"mini"},["Records not available. Check server."]));
    return;
  }
  if(!recs.length){
    recentHost.appendChild(el("div",{class:"mini"},["No PBJs yet. Submit intake (or Auto-Fill) to create one."]));
    return;
  }
  recs.slice(0,40).forEach(r=> recentHost.appendChild(pbjCard(r)));
}

async function handleIntakeSubmit(payload){
  try{
    console.log("PBJ module received intake submit:", payload);
    setStatus("Intake received");
    const pbj = normalizePBJFromIntake(payload || {});
    await Records.initAuto({prefer:"local"});
    await Records.upsertAsync(pbj);
    toast("PBJ saved", "ok");
    setStatus("PBJ saved");
    try{ localStorage.setItem("udl_nav_open_record", pbj.id); }catch{}
    await refreshRecent();
    // immediate UI insert safety: if refresh didn't pick it up, add it now
    try{
      if(recentHost && !document.querySelector(`[data-record-id="${pbj.id}"]`)){
        recentHost.prepend(pbjCard(pbj));
      }
    }catch{}
    setTimeout(()=>{ try{ focusFromNav(); }catch{} }, 120);
  }catch(e){
    console.error(e);
    toast("PBJ save failed", "err");
  }
}


let statusPillEl = null;
function setStatus(msg){
  try{ if(statusPillEl) statusPillEl.textContent = msg; }catch{}
}
function applyLayoutState(rootEl, collapseBtn){
  const collapsed = lsGet("udl_pbj_intake_collapsed", "0") === "1";
  rootEl.classList.toggle("intake-collapsed", collapsed);
  collapseBtn.textContent = collapsed ? "Show Intake" : "Hide Intake";
}

function render(){
  const root = document.getElementById("root");
  root.innerHTML = "";

  const collapseBtn = el("button",{class:"btn", id:"collapseIntakeBtn"},["Hide Intake"]);
  const hdr = el("div",{class:"hdr"},[
    el("div",{},[
      el("h1",{class:"page-title", style:"margin:0;"},["PBJ"]),
      el("div",{class:"subtle"},["Intake → Records → Recent list"]),
      el("div",{class:"row", style:"gap:10px; margin-top:6px;"},[
        el("span",{class:"chip", id:"statusPill"},["Ready"])
      ])
    ]),
    el("div",{class:"row", style:"gap:10px; justify-content:flex-end;"},[
      collapseBtn,
      el("button",{class:"btn", id:"seedBtn"},["Create Sample PBJ"]),
      el("button",{class:"btn", id:"refreshBtn"},["Refresh"]),
    ])
  ]);

  const leftPane = el("div",{class:"pane leftPane"},[
    el("div",{class:"card"},[
      el("div",{class:"hd"},[
        el("div",{class:"h3"},["Input"]),
        el("span",{class:"chip"},["Embedded"])
      ]),
      el("div",{class:"bd"},[
        el("iframe",{src:"/ui/modules/pbj/intake.html", class:"intakeFrame"})
      ])
    ])
  ]);

  const splitter = el("div",{class:"splitter", title:"Drag to resize"},[
    el("div",{class:"splitterGrip"},[])
  ]);

  recentHost = el("div",{class:"listHost"},[]);
  const rightPane = el("div",{class:"pane rightPane"},[
    el("div",{class:"card"},[
      el("div",{class:"hd"},[
        el("div",{class:"h3"},["Recent PBJs"]),
        el("span",{class:"chip"},["Records"])
      ]),
      el("div",{class:"bd"},[recentHost])
    ])
  ]);

  const grid = el("div",{class:"splitGrid"},[leftPane, splitter, rightPane]);

  root.appendChild(hdr);
  root.appendChild(grid);
  statusPillEl = document.getElementById('statusPill');

  // collapse / show
  applyLayoutState(root, collapseBtn);
  collapseBtn.addEventListener("click", ()=>{
    const collapsed = lsGet("udl_pbj_intake_collapsed", "0") === "1";
    lsSet("udl_pbj_intake_collapsed", collapsed ? "0" : "1");
    applyLayoutState(root, collapseBtn);
  });

  // resize drag
  const minLeft = 320;
  const maxLeft = 980;
  let dragging = false;

  function setLeftW(px){
    const clamped = Math.max(minLeft, Math.min(maxLeft, px));
    document.documentElement.style.setProperty("--pbj-leftW", clamped + "px");
    lsSet("udl_pbj_leftW", String(clamped));
  }

  const savedW = parseInt(lsGet("udl_pbj_leftW", "720"), 10);
  if(!Number.isNaN(savedW)) setLeftW(savedW);

  splitter.addEventListener("pointerdown", (e)=>{
    if(root.classList.contains("intake-collapsed")) return;
    dragging = true;
    splitter.setPointerCapture(e.pointerId);
    document.body.classList.add("resizing");
  });
  splitter.addEventListener("pointermove", (e)=>{
    if(!dragging) return;
    const rect = grid.getBoundingClientRect();
    const leftW = e.clientX - rect.left;
    setLeftW(leftW);
  });
  splitter.addEventListener("pointerup", ()=>{
    dragging = false;
    document.body.classList.remove("resizing");
  });

  document.getElementById("seedBtn").addEventListener("click", async ()=>{
    try{
      await Records.initAuto({prefer:"local"});
      const now = new Date().toISOString();
      const r = {
        id: uid("PBJ"),
        type:"pbj",
        title:"Sample PBJ — Network as a Service",
        status:"new",
        priority:"P2",
        owner:"Michael",
        tags:["sample","naas"],
        workspaceId:"default",
        links:{ parentId: undefined, relatedIds: [] },
        fields:{ description:"Seed PBJ to test flows. Replace with real intake later." },
        evidence:{ notes:"" },
        audit:[{ at: now, msg:"Seeded sample PBJ" }],
        createdAt: now,
        updatedAt: now,
      };
      await Records.upsertAsync(r);
      toast("Sample PBJ created", "ok");
      await refreshRecent();
    // immediate UI insert safety: if refresh didn't pick it up, add it now
    try{
      if(recentHost && !document.querySelector(`[data-record-id="${pbj.id}"]`)){
        recentHost.prepend(pbjCard(pbj));
      }
    }catch{}
    }catch(e){
      console.error(e);
      toast("Seed failed", "err");
    }
  });

  document.getElementById("refreshBtn").addEventListener("click", refreshRecent);

  refreshRecent();
  setTimeout(()=>{ try{ focusFromNav(); }catch{} }, 140);
}

// Listen for intake iframe submissions
window.addEventListener("message", (ev)=>{
  try{
    const msg = ev.data;
    if(!msg || msg.type !== "pbj-intake-submit") return;
    handleIntakeSubmit(msg.payload || {});
  }catch(e){
    console.error(e);
  }
});

render();
